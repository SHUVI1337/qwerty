```python
Создать график функции
```


```python
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib import style

plt.style.use('dark_background')
fig = plt.figure()
ax = plt.axes(xlim=(0, 4), ylim=(-2, 2))
line, = ax.plot([], [], lw=3)
def init():
    line.set_data([], [])
    return line,
def animate(i):
    x = np.linspace(0, 4, 1000)
    y = 10*x**2 * np.sin(x**2 + 5)
    line.set_data(x, y)
    return line,
anim = FuncAnimation(
    fig,
    animate,
    init_func=init,
    frames=200,
    interval=20,
    blit=True)
anim.save('sine_wave.gif', writer='imagemagick')
```

    MovieWriter imagemagick unavailable; using Pillow instead.
    


    
![png](output_1_1.png)
    

